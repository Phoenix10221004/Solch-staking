import express from 'express'
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import db from './app/models/index';
import cors from 'cors';
import routes from './app/routes/staking.routes';
dotenv.config()
const app = express()

app.use(cors())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))

db.mongoose
  .connect(db.url)
  .then(() => {
    console.log("Connected to the database!");
  })
  .catch((err) => {
    console.log("Cannot connect to the database!", err);
    process.exit();
  });
app.use(express.static(`${__dirname}/build`))
app.use('/api/staking', routes);
app.use('/*', (req, res) => {
  res.sendFile(`${__dirname}/build/index.html`)
})

const port = process.env.PORT

app.listen(port || 5000, () => {
  console.info(`server started on port ${port}`); // eslint-disable-line no-console
});