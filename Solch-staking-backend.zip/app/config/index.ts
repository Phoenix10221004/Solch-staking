import * as CONFIG_DEV from './dev';
import * as CONFIG_MAIN from './main';
const CONFIG = CONFIG_MAIN;
export default CONFIG;


