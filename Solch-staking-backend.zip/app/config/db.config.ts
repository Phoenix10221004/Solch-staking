
export const url = "mongodb+srv://solacash:JEY0P9C233vYQsN4@cluster0.k6ivr.mongodb.net/staking_db";