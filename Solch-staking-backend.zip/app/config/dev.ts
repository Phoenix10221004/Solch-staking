export const CLUSTER_API = 'https://api.devnet.solana.com';
export const PROGRAM_ID = '6Pf6bCr94Y8UFwDWneMbyWNUDtv9LRowVwGR9DzKUACD';
export const PRIVATE_KEY = "2enST1ZP3zuAXz7ht5Czg2gq2c5LqcaPa2jFCU1TNxBMyVYVNjpeuHWc4svWxFGN3AfWmsEQo8nYByzvziWGW4E3";
export const DAYTIME = 10;
export const DECIMAL = 1000000000;
export const POOLTYPES = [
    {days: 7, fee: 1, minAmount: 20, apy: 2},
    {days: 30, fee: 1, minAmount: 100, apy: 20},
    {days: 90, fee: 1, minAmount: 500, apy: 80},
    {days: 180, fee: 1, minAmount: 1000, apy: 400},
    {days: 365, fee: 1, minAmount: 2000, apy: 1020},
]
// mainnet deployer wallet
