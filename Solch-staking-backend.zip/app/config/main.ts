export const CLUSTER_API ='https://misty-green-dream.solana-mainnet.quiknode.pro/324b64b0ef2638385e0facb9a7cde25ed22f91f9/';
export const PROGRAM_ID = '6Pf6bCr94Y8UFwDWneMbyWNUDtv9LRowVwGR9DzKUACD';
export const PRIVATE_KEY = "5odBvpq7528TP6zmrX2DZPvySSQ6KB8ubXQHTsucRJDZn4VWvHyd8jqXKeD3Qe3o9PQeYaBa4kqkDH5gHWUjsNYC";
export const DAYTIME = 86400;
export const DECIMAL = 1000000000;

export const POOLTYPES = [
    {days: 7, fee: 1, minAmount: 20, apy: 0.287},
    {days: 30, fee: 1, minAmount: 100, apy: 5.753},
    {days: 90, fee: 1, minAmount: 500, apy: 55.479},
    {days: 180, fee: 1, minAmount: 1000, apy: 229.315},
    {days: 365, fee: 1, minAmount: 2000, apy: 950},
]