
import * as anchor from '@project-serum/anchor';
import db from '../models'
import { PublicKey } from '@solana/web3.js';

import { getProgram, getAllUsers, addUser, updateInfo, deleteUser, getUsersByKey, updateStartTime, connection} from'../services/index';
import CONFIG from '../config';
const {PROGRAM_ID, DAYTIME, DECIMAL, POOLTYPES}  = CONFIG;
// Create and Save a new StakingInfo

export const create = async (req, res) => {
    if (!req.body.user) {
        res.status(400).send({message: "user can not be empty!", success: false});
        return;
    } else if (req.body.index === -1) {
        res.status(400).send({
            message: "index can not be under zero",
            success: false
        });
        return;
    }
    let {user, index, amount} = req.body;
    let info: any;//to check if user already stake before or not
    let pool, nonce_pool: any;
    let i: any;
    [pool, nonce_pool] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from('pool' + index), new PublicKey(user).toBuffer()],
      new PublicKey(PROGRAM_ID)
      );
    info = await connection.getAccountInfo(pool);

    if ( info === null || undefined) {
      //this is first time for user to stake for this pool
          for (i = 0;info === null || info === undefined; i++) {
            [pool, nonce_pool] = await anchor.web3.PublicKey.findProgramAddress(
                [Buffer.from('pool' + index), new PublicKey(user).toBuffer()],
                new PublicKey(PROGRAM_ID)
                );
              console.log("user: ", i, user);
            info = await connection.getAccountInfo(pool);
          }
          const program = await getProgram();
          const poolData = await program.account.pool.fetch(pool);
          let startTime = poolData.startTime;
          let endTime = poolData.endTime;
          let reward = Number.parseFloat(poolData.reward.toString())/DECIMAL
          amount *= (1- POOLTYPES[index].fee / 100 );
          console.log("data from chain", poolData);
          const userInfo = await getUsersByKey(user);
          if ( userInfo.length === 0 ) {
            let duration =( endTime - startTime ) / DAYTIME;
            const data = {
              user: user,
              index: index,
              duration: duration,
              reward: reward,
              amount: amount,
              startTime: startTime
            };
            console.log("data to save into db", poolData);
            try {
              const result = await addUser(data);
              res.status(200).send({
                success: true,
                message: "success",
                data: result
              })
            } catch (error) {
              console.log(error);
              res.status(405).send({
                success: false,
                message: error.message || "something went wrong when create"
              })
            }
          } else {
            let duration = ( endTime - startTime ) / DAYTIME + userInfo[0].duration;
            reward = userInfo[0].reward;
            amount = amount + userInfo[0].amount;
            const data = {
              user: user,
              index: index,
              duration: duration,
              reward: reward,
              amount: amount,
              startTime: startTime
            };  
            try {
              const result = await updateInfo(data);
              res.status(200).send({
                success: true,
                data: result,
              })
            } catch (error) {
              console.log(error);
              res.status(500).send({
                success: false,
                message: "Something wrong when save data into db"
              })
            }     
          }

    } else {
      //this is not first time user stake
      //so add duration and amount and reward for last reward
      const result = await getUsersByKey(user);
      if ( result.length === 0 ) {
        res.status(500).send({
          success: false,
          message: "db error. not found user"
        });
      } else {
        const program = await getProgram();
        let poolData = await program.account.pool.fetch(pool);
        let startTime = poolData.startTime;
        let endTime = poolData.endTime;
        amount *= (1- POOLTYPES[index].fee / 100 );
        let duration =( endTime - startTime ) / DAYTIME;
        if ( duration === 0 ) {
          for ( let i = 0; duration === 0; i++ ) {
            poolData = await program.account.pool.fetch(pool);
            startTime = poolData.startTime;
            endTime = poolData.endTime;
            duration = (endTime - startTime) / DAYTIME;
          }
        }
        
        let daysPassed = duration + result[0].duration;
        let data = {
          user: user,
          index: index,
          duration: daysPassed,
          reward: result[0].reward,
          startTime: startTime,
          amount: result[0].amount + amount
        }
        try {
          const updateResult = await updateInfo(data);
          res.status(200).send({
            success: true,
            data: updateResult
          });
        } catch (error) {
          console.log(error);
          res.status(500).send({
            success: true,
            message: `${error}`
          });
        }
        
    }
    
    };
}

// Retrieve all data from the database.
export const findAll = async (req, res) => {
  try {
    const result = await getAllUsers();
    res.status(200).send({
      success: true,
      data: result});
  } catch (error) {
    console.log(error);
    res.status(404).send({
      success: false,
      message: error.message
    })
  }
};

export const updateOne = async (req, res) => {
  if (!req.body.user) {
    res.status(400).send({message: "user can not be empty!", success: false});
    return;
  } else if (req.body.index === -1) {
      res.status(400).send({
          message: "index can not be under zero",
          success: false
      });
      return;
  }
  let {user, index} = req.body;
  let userInfoInDB = await getUsersByKey(user);
  if (userInfoInDB.length === 0 ) {
    res.status(300).send({
      success: false,
      message: "no data in db"
    });
  }
  if ( index === userInfoInDB[0].index) {
    let info: any = userInfoInDB[0].startTime;
    let pool, nonce_pool: any;
    let i: any;
    const program = await getProgram();
    [pool, nonce_pool] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from('pool' + index), new PublicKey(user).toBuffer()],
      new PublicKey(PROGRAM_ID)
      );
    let poolData = await program.account.pool.fetch(pool);
    let startTime = poolData.startTime;
    for (i = 0; info === startTime; i++) {
     [pool, nonce_pool] = await anchor.web3.PublicKey.findProgramAddress(
        [Buffer.from('pool' + index), new PublicKey(user).toBuffer()],
        new PublicKey(PROGRAM_ID)
      );
        
      poolData = await program.account.pool.fetch(pool);
      info = poolData.startTime;
    }
    let amount = (Number.parseFloat(poolData.stakedAmount.toString())/DECIMAL);
    let reward = Number.parseFloat(poolData.reward.toString())/DECIMAL;
    
      try {
        const userResult = await getUsersByKey(user);
        if ( userResult.length > 0) {
            let data = {
              user: user,
              index: index,
              duration: userResult[0].duration,
              reward: reward + userResult[0].reward ,
              amount: amount,
              startTime: poolData.startTime
              }
              const result = await updateInfo(data);
              res.status(200).send({
                success: true,
                data: result
            });
        } else {
          res.status(300).send({
            success: false,
            message: "no data in db"
          });
        }
      } catch (error) {
        console.log(error);
        res.status(500).send({
          success: false,
          message: error.message || "Something wrong"
        });
      }
  } else {
    let info: any;
    let pool, nonce_pool: any;
    let i: any;
    const program = await getProgram();
    [pool, nonce_pool] = await anchor.web3.PublicKey.findProgramAddress(
      [Buffer.from('pool' + index), new PublicKey(user).toBuffer()],
      new PublicKey(PROGRAM_ID)
      );
    let poolData = await program.account.pool.fetch(pool);
    let startTime = poolData.startTime;
    info = startTime;
    for (i = 0; info === startTime; i++) {
     [pool, nonce_pool] = await anchor.web3.PublicKey.findProgramAddress(
        [Buffer.from('pool' + index), new PublicKey(user).toBuffer()],
        new PublicKey(PROGRAM_ID)
      );
        
      poolData = await program.account.pool.fetch(pool);
      info = poolData.startTime;
    }
    let amount = (Number.parseFloat(poolData.stakedAmount.toString())/DECIMAL);
    let reward = Number.parseFloat(poolData.reward.toString())/DECIMAL;
    
      try {
        const userResult = await getUsersByKey(user);
        if ( userResult.length > 0) {
            let data = {
              user: user,
              index: index,
              duration: userResult[0].duration,
              reward: reward + userResult[0].reward ,
              amount: amount,
              startTime: poolData.startTime
              }
              const result = await updateInfo(data);
              res.status(200).send({
                success: true,
                data: result
            });
        } else {
          res.status(300).send({
            success: false,
            message: "no data in db"
          });
        }
      } catch (error) {
        console.log(error);
        res.status(500).send({
          success: false,
          message: error.message || "Something wrong"
        });
      }
  }
  
}

export const updateAll = async(req, res) => {
  const result = await getAllUsers();
  for (let i = 0; i< result.length; i++ ) {
    const users = await getUsersByKey(result[i].user);
    for ( let j = 0; j< users.length; j++ ) {
      let index = users[j].index;
      let user = users[j].user;
      let [pool, nonce_pool] = await anchor.web3.PublicKey.findProgramAddress(
        [Buffer.from('pool' + index), new PublicKey(user).toBuffer()],
        new PublicKey(PROGRAM_ID)
        );
      const program = await getProgram();
      const poolData = await program.account.pool.fetch(pool);
      let duration = (poolData.endTime - poolData.startTime) / DAYTIME;
      let amount = (Number.parseFloat(poolData.stakedAmount.toString())/DECIMAL);
      let reward = Number.parseFloat(poolData.reward.toString())/DECIMAL;
      if ( amount > 0 ) {
        let data = {
        user: user,
        index: index,
        duration: duration,
        reward: reward,
        amount: amount,
        startTime: poolData.startTime
      };
       try {
        const result = await updateInfo(data);
        res.status(200).send({
          success: true,
          data: result
        })
      } catch (error) {
        console.log(error);
        res.status(500).send({
          success: false,
          message: error.message || "Something wrong"
        });
      }
    } else {
      try {
        const result = await deleteUser(user);
        console.log(result);
          res.status(200).send({
            success: true,
            data: result
          })
      } catch (error) {
        console.log(error);
        res.status(500).send({
          message: error.message || "Error when delete",
          success: false
        })
      }
    }

    }
  }
}


