
import {url} from '../config/db.config';
import mongoose from 'mongoose';
import Staking from './staking.model';
mongoose.Promise = global.Promise;
const db = {
    mongoose: mongoose,
    url: url,
    staking: Staking
}
export default db;