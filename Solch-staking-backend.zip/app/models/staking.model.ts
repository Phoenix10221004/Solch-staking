import mongoose from 'mongoose'
  const schema = new mongoose.Schema(
    {
      user: {
        type: String,
        required: true,
      },
      index: {
        type: Number, 
        required: true,
      },
      duration: {
        type: Number,
        required: true
      },
      reward: {
        type: Number, 
        required: true
      },
      amount: {
        type: Number,
        required: true
      },
      startTime: {
        type: Number,
        required: true
      }
    },
    { timestamps: true }
  );
  
  schema.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    object.id = _id;
    return object;
  });
  const Staking = mongoose.model("staking", schema);
  // return Staking
  export default Staking;
  // };
  