import * as  anchor  from '@project-serum/anchor';
import { Commitment, ConnectionConfig } from '@solana/web3.js';
import {IDL} from '../constants/idl/index';
import NodeWallet from '@project-serum/anchor/dist/cjs/nodewallet';
import { bs58 } from '@project-serum/anchor/dist/cjs/utils/bytes';
import db from '../models';
import CONFIG from '../config';
const {CLUSTER_API, PROGRAM_ID, PRIVATE_KEY, DAYTIME, DECIMAL}  = CONFIG;
const { PublicKey, Keypair, Connection, Transaction } = anchor.web3;

const UPDATE_AUTHORITY = Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY));
const staking = db.staking;

export const connection = new Connection(CLUSTER_API, {
    skipPreflight: true,
    preflightCommitment: 'confirmed' as Commitment 
} as ConnectionConfig);

export const getProvider = () => {
    const connection = new Connection(CLUSTER_API, {
        skipPreflight: true,
        preflightCommitment: 'confirmed' as Commitment 
    } as ConnectionConfig);

    return new anchor.Provider(connection,  new NodeWallet(UPDATE_AUTHORITY), {
        skipPreflight: true,
        preflightCommitment: 'confirmed' as Commitment 
    }as ConnectionConfig)
}

export const getProgram = () => {
    const provider = getProvider();
    const program = new anchor.Program(IDL, new PublicKey(PROGRAM_ID), provider);
    return program;
}

export const getCurrentChainTime = async () => {
    const connection = new Connection(CLUSTER_API, {
        skipPreflight: true,
        preflightCommitment: 'confirmed' as Commitment 
    } as ConnectionConfig);
  
    const slot = await connection.getSlot('confirmed');
    const curChainTime = await connection.getBlockTime(slot);
    return curChainTime;
}

export const getAllUsers = async () => {
    const result = await staking.find({});
    return result;
}

export const getUsersByKey = async (key) => {
    const result = await staking.find({
        user: key
    });
    return result;
}
export const getUserByKeyIndexTime = async (key, index, time) => {
    const result = await staking.find({
        user: key,
        index: index,
        startTime: time
    });
    return result;
}

export const getUserByKeyIndex = async (key, index) => {
    const result = await staking.find({
        user: key,
        index: index,
    });
    return result;
}
export const addUser = async (data) => {
    const result = await staking.create(data);
    result.save();
    return result;
}

export const updateInfo = async (data) => {
    try {
        const result = await getUsersByKey(data.user);
        if ( result.length !== 0) {
            result[0].user = data.user
            result[0].index = data.index;
            result[0].reward = data.reward;
            result[0].duration = data.duration;
            result[0].amount = data.amount;
            result[0].startTime = data.startTime
            result[0].save();
            return result[0];
        }
    } catch (error) {
        console.log(error)
    }
}
export const updateStartTime = async (data) => {
    try {
        const result = await getUserByKeyIndexTime(data.user, data.index, 0);
        if ( result.length != 0) {
            result[0].user = data.user
            result[0].index = data.index;
            result[0].reward = data.reward;
            result[0].duration = data.duration;
            result[0].amount = data.amount;
            result[0].startTime = data.startTime
            result[0].save();
            return result[0];
        }
    } catch (error) {
        console.log(error)
    }
}
export const deleteUser = async (user) => {
    try {
        const result = await staking.deleteMany({
            user: user
        })
        return result;
    } catch (error) {
        console.log(error)
    }
}