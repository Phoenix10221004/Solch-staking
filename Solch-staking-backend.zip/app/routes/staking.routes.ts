  import express from 'express'
  import {create, updateOne, findAll} from '../controllers/staking.controller';
  const router = express.Router();
  router.post('/', create);
  router.get('/user', findAll);
  router.post('/update', updateOne);

  export default router;
  