import * as CONFIG_MAIN from './main';
import * as CONFIG_DEV from './dev';
let CONFIG: any = CONFIG_MAIN;
export default CONFIG;
