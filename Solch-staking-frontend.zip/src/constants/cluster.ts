const mainnet = 'https://misty-green-dream.solana-mainnet.quiknode.pro/324b64b0ef2638385e0facb9a7cde25ed22f91f9/';
const devnet = 'https://api.devnet.solana.com';
export {
    mainnet,
    devnet
};